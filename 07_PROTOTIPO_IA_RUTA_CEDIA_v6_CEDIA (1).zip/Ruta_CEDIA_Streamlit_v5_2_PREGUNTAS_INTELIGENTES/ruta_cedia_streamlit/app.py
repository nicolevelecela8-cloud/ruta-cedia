from __future__ import annotations

import json
import os
from collections import defaultdict
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components
from dotenv import load_dotenv

from engine import (
    M, TOOLS, GAPS, ROUTE, tool_public_view, run_engine, recommend_from_gap,
    methodology_qa, next_checks_for_tool, route_info_for_tool, tool_followup_answer
)
from llm import diagnose, coach_tool
from styles import APP_CSS
from tool_templates import schema_for, empty_answers, render_preview
from service_router import SERVICE_CATALOG, recommend_services

load_dotenv()

st.set_page_config(
    page_title="Ruta CEDIA Innovación",
    page_icon="🧭",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(APP_CSS, unsafe_allow_html=True)

def hero(title: str, text: str):
    st.markdown(
        f'<div class="hero"><h1>{title}</h1><p>{text}</p></div>',
        unsafe_allow_html=True
    )

def family_icon(family: str) -> str:
    return {
        "Ideación": "💡",
        "Marketing": "🎯",
        "Modelo de Negocio": "🧩",
        "Prototipado": "🛠️",
        "Servucción": "🤝",
        "Tendencias": "🔭",
        "Validación": "🧪",
        "Maduración tecnológica": "📈",
        "Transferencia / PI": "🔐",
        "Adopción / Comercialización": "🚀",
    }.get(family, "🧭")

def show_tool_card(tool_id: str, compact: bool = False):
    t = tool_public_view(tool_id)
    route = t.get("route") or {}
    route_label = route.get("etapa") or "Ruta transversal"
    st.markdown(
        f"""
        <div class="card">
            <span class="pill">{family_icon(t['family'])} {t['family']}</span>
            <span class="pill">{route_label}</span>
            <h3>{t['name']}</h3>
            <p>{t['description'] or ''}</p>
            <p class="smallmuted"><b>Resultado:</b> {t['output'] or 'Por validar'}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    if not compact:
        with st.expander("Ver ficha metodológica"):
            st.markdown(f"**Propósito:** {t['purpose'] or '—'}")
            st.markdown(f"**Cuándo usar:** {t['when_use'] or '—'}")
            st.markdown(f"**Cuándo no usar:** {t['when_not'] or '—'}")
            st.markdown(f"**Prerrequisito de evidencia:** {t['prerequisite'] or '—'}")
            st.markdown(f"**Pasos:** {t['steps'] or '—'}")
            st.markdown(f"**Evidencia esperada:** {t['evidence'] or '—'}")
            st.caption(f"Fuente metodológica: {t['source'] or 'No registrada'}")

def show_recommendation(rec: dict):
    if rec["type"] == "action_service":
        st.markdown(
            f"""
            <div class="resultbox">
                <span class="pill">ACCIÓN / SERVICIO</span>
                <h2>{rec['title']}</h2>
                <p>{rec['reason']}</p>
                <p><b>Derivación sugerida:</b> {rec['service']}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if rec.get("support_tool"):
            st.info(
                f"Como herramienta de apoyo, no como sustituto de la acción principal: "
                f"{rec['support_tool']['name']}."
            )
            show_tool_card(rec["support_tool"]["id"], compact=True)
        st.caption(rec.get("validation_note", ""))
        return

    if rec["type"] == "tool":
        tool = rec["tool"]
        st.markdown(
            f"""
            <div class="resultbox">
                <span class="pill">RECOMENDACIÓN METODOLÓGICA · {rec.get('priority','')}</span>
                <h2>{rec['title']}</h2>
                <p><b>Bloqueo interpretado:</b> {rec.get('gap') or '—'}</p>
                <p>{rec.get('reason') or ''}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("#### Antes de empezar")
            st.write(rec.get("prerequisite") or "—")
            if rec.get("if_missing"):
                st.caption("Si falta esa evidencia: " + rec["if_missing"])
        with c2:
            st.markdown("#### Al terminar")
            st.write(rec.get("criterion") or tool.get("evidence") or "—")
        route = tool.get("route") or {}
        if route:
            st.info(
                f"**Etapa de la ruta final:** {route.get('etapa')} · "
                f"**Mentoría que puede alimentar:** {route.get('mentoria')}"
            )
        st.markdown("#### Siguiente evaluación")
        st.write(rec.get("next") or "Reevaluar la ruta según la nueva evidencia.")

        connected = next_checks_for_tool(tool["id"])
        if connected:
            st.markdown("#### Brechas/herramientas relacionadas que conviene revisar después")
            st.caption("No son pasos obligatorios: se muestran solo cuando existe una relación metodológica explícita en 07_DEPENDENCIAS.")
            for item in connected[:3]:
                relation_label = "Siguiente chequeo posible" if item["relation"] == "Antes de" else "Revisión complementaria"
                st.write(
                    f"**{relation_label}:** {item['tool_name']} "
                    f"— brecha asociada: {item.get('gap_name') or 'por reevaluar'}."
                )

        with st.expander("Ver ficha completa de la herramienta"):
            show_tool_card(tool["id"], compact=False)
        st.caption(rec.get("validation_note", ""))
        return

    if rec["type"] == "no_repeat":
        st.success(rec["reason"])
        st.write("**Siguiente paso:**", rec.get("next") or "Reevaluar la ruta.")
        return

    st.warning(rec.get("reason") or "Se necesita más información antes de recomendar.")


NAV_PAGES = [
    "Inicio",
    "Explorar herramientas",
    "Desarrollar herramienta",
    "Ruta final",
    "Diagnóstico con IA",
    "Pasaporte del proyecto",
    "TRL / CRL",
    "Servicios CEDIA",
    "Metodología",
]
PAGE_SLUGS = {
    "Inicio": "inicio",
    "Explorar herramientas": "herramientas",
    "Desarrollar herramienta": "desarrollar",
    "Ruta final": "ruta-final",
    "Diagnóstico con IA": "diagnostico",
    "Pasaporte del proyecto": "pasaporte",
    "TRL / CRL": "trl-crl",
    "Servicios CEDIA": "servicios",
    "Metodología": "metodologia",
}
SLUG_TO_PAGE = {v: k for k, v in PAGE_SLUGS.items()}

def _sync_query_from_nav():
    page = st.session_state.get("nav_page", "Inicio")
    st.query_params["page"] = PAGE_SLUGS.get(page, "inicio")

def go_to(page_name: str):
    st.session_state.nav_page = page_name
    st.query_params["page"] = PAGE_SLUGS.get(page_name, "inicio")

def open_tool_builder(tool_id: str):
    st.session_state.active_tool_id = tool_id
    st.session_state.builder_tool_select = tool_id
    st.session_state.nav_page = "Desarrollar herramienta"
    st.query_params["page"] = PAGE_SLUGS["Desarrollar herramienta"]

def _tool_stage_number(tool_id: str):
    info = route_info_for_tool(tool_id) or {}
    try:
        return int(info.get("stage"))
    except Exception:
        return None

def _project_backup_payload():
    return {
        "version":"Ruta CEDIA v5.2",
        "chat":st.session_state.get("chat", []),
        "last_diagnosis":st.session_state.get("last_diagnosis"),
        "last_recommendation":st.session_state.get("last_recommendation"),
        "active_tool_id":st.session_state.get("active_tool_id"),
        "tool_work":st.session_state.get("tool_work", {}),
    }

def sidebar():
    requested_slug = st.query_params.get("page")
    if requested_slug in SLUG_TO_PAGE and "nav_page" not in st.session_state:
        st.session_state.nav_page = SLUG_TO_PAGE[requested_slug]
    elif "nav_page" not in st.session_state:
        st.session_state.nav_page = "Inicio"

    st.sidebar.markdown("## 🧭 Ruta CEDIA")
    st.sidebar.caption("MVP funcional · v5.2 · propuesta metodológica v12")
    page = st.sidebar.radio(
        "Navegación",
        NAV_PAGES,
        key="nav_page",
        on_change=_sync_query_from_nav,
        label_visibility="collapsed",
    )
    st.sidebar.divider()
    local_model = os.getenv("OLLAMA_MODEL", "").strip()
    st.sidebar.markdown("**Modo de diagnóstico**")
    if local_model:
        st.sidebar.success(f"IA local: {local_model}")
        st.sidebar.caption("La conversación se procesa en tu computador mediante localhost.")
        use_ai = st.sidebar.toggle("Usar IA local", value=True)
    else:
        st.sidebar.warning("Motor local DEMO")
        st.sidebar.caption("Funciona sin internet. Puedes activar un modelo local con Ollama cuando quieras.")
        use_ai = False
    return page, use_ai

page, use_ai = sidebar()

if page == "Inicio":
    hero(
        "Ruta CEDIA Innovación",
        "Cuéntale a la IA qué está frenando tu proyecto, identifica la brecha y recorre una ruta de herramientas, evidencia y apoyo CEDIA sin tener que conocer la metodología de antemano.",
    )
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown('<div class="card"><h3>💬 No sé qué necesito</h3><p>Describe tu problema con tus propias palabras. La IA pregunta, interpreta y consulta la metodología.</p></div>', unsafe_allow_html=True)
        st.button("Abrir diagnóstico", key="home_diag", use_container_width=True, on_click=go_to, args=("Diagnóstico con IA",))
    with c2:
        st.markdown('<div class="card"><h3>🧰 Explorar herramientas</h3><p>Consulta las 34 herramientas del portafolio propuesto: 26 CEDIA + 8 benchmark.</p></div>', unsafe_allow_html=True)
        st.button("Explorar herramientas", key="home_tools", use_container_width=True, on_click=go_to, args=("Explorar herramientas",))
    with c3:
        st.markdown('<div class="card"><h3>📈 TRL / CRL</h3><p>Usa la madurez como contexto del proyecto. No se fuerza una herramienta por estar en un nivel específico.</p></div>', unsafe_allow_html=True)
        st.button("Evaluar TRL / CRL", key="home_trl", use_container_width=True, on_click=go_to, args=("TRL / CRL",))

    st.markdown("### Qué hace diferente a este prototipo")
    st.write(
        "La IA no elige herramientas libremente. Primero interpreta lo que dice el investigador; "
        "después un motor determinista consulta brechas, evidencias, reglas y prerrequisitos provenientes del Excel metodológico."
    )
    st.markdown(
        '<div class="note"><b>Principio:</b> CEDIA diseña la ruta. La inteligencia artificial ayuda a recorrerla.</div>',
        unsafe_allow_html=True,
    )

elif page == "Explorar herramientas":
    hero(
        "Explorar herramientas",
        "Catálogo construido desde la hoja 01_HERRAMIENTAS del Excel metodológico.",
    )
    query = st.text_input("Buscar", placeholder="Ej. cliente, problema, tendencias, prototipo...")
    families = ["Todas"] + sorted({t.get("FAMILIA") for t in TOOLS.values() if t.get("FAMILIA")})
    family = st.selectbox("Familia", families)

    q = query.lower().strip()
    selected = []
    for tid, t in TOOLS.items():
        haystack = " ".join(str(t.get(k) or "") for k in [
            "NOMBRE","FAMILIA","DESCRIPCION_CORTA","PROPOSITO","PROBLEMA_QUE_RESUELVE","CUANDO_USAR"
        ]).lower()
        if family != "Todas" and t.get("FAMILIA") != family:
            continue
        if q and q not in haystack:
            continue
        selected.append(tid)

    st.caption(f"{len(selected)} herramienta(s)")
    cols = st.columns(2)
    for i, tid in enumerate(selected):
        with cols[i % 2]:
            show_tool_card(tid)
            st.button(
                "Desarrollar con IA",
                key=f"explore_build_{tid}",
                use_container_width=True,
                on_click=open_tool_builder,
                args=(tid,),
            )

elif page == "Desarrollar herramienta":
    hero(
        "Desarrolla la herramienta con IA",
        "La IA te acompaña campo por campo, pero no inventa información. A la derecha ves cómo debería quedar la herramienta finalizada con tus propios datos.",
    )
    if "tool_work" not in st.session_state:
        st.session_state.tool_work = {}
    active = st.session_state.get("active_tool_id")
    tool_ids = list(TOOLS.keys())
    default_idx = tool_ids.index(active) if active in tool_ids else 0
    selected_tool_id = st.selectbox(
        "Herramienta",
        tool_ids,
        index=default_idx,
        format_func=lambda x: f"{TOOLS[x].get('NOMBRE')} · {TOOLS[x].get('FAMILIA')}",
        key="builder_tool_select",
    )
    st.session_state.active_tool_id = selected_tool_id
    raw_tool = TOOLS[selected_tool_id]
    public = tool_public_view(selected_tool_id)
    schema = schema_for(selected_tool_id, raw_tool)
    if selected_tool_id not in st.session_state.tool_work:
        st.session_state.tool_work[selected_tool_id] = empty_answers(selected_tool_id, raw_tool)
    answers = st.session_state.tool_work[selected_tool_id]

    route = route_info_for_tool(selected_tool_id) or {}
    st.markdown(
        f"**{public['name']}** · {public['family']} · "
        f"Etapa: **{route.get('etapa') or 'Transversal'}**"
    )
    st.caption(public.get("purpose") or "")

    left, right = st.columns([1.0, 1.15], gap="large")
    with left:
        st.markdown("### Completa la herramienta")
        st.caption("Escribe únicamente información real de tu proyecto. Puedes pedir retroalimentación de la IA en cualquier campo.")
        for idx, (key, label) in enumerate(schema["fields"], start=1):
            st.markdown(f"**{idx}. {label}**")
            value = st.text_area(
                label,
                value=answers.get(key, ""),
                key=f"builder_{selected_tool_id}_{key}",
                label_visibility="collapsed",
                height=90,
                placeholder=f"Completa: {label}",
            )
            answers[key] = value
            c_ai, c_help = st.columns([1,2])
            with c_ai:
                if st.button("Revisar con IA", key=f"coach_{selected_tool_id}_{key}"):
                    with st.spinner("Revisando con la IA local…"):
                        feedback = coach_tool(
                            selected_tool_id,
                            public["name"],
                            label,
                            value,
                            answers,
                            public.get("purpose") or "",
                            public.get("steps") or "",
                            use_ai=use_ai,
                        )
                    st.session_state[f"feedback_{selected_tool_id}_{key}"] = feedback
            fb = st.session_state.get(f"feedback_{selected_tool_id}_{key}")
            if fb:
                st.info(f"**IA · {fb.get('quality','')}** — {fb.get('feedback','')}")
                if fb.get("missing"):
                    st.caption("Falta o conviene precisar: " + fb["missing"])
                if fb.get("example"):
                    with st.expander("Ver ejemplo ilustrativo"):
                        st.write(fb["example"])
            st.divider()
        st.session_state.tool_work[selected_tool_id] = answers

    with right:
        st.markdown("### Así debería verse finalizada")
        st.caption("La vista cambia en tiempo real con tus respuestas. No es una imagen genérica: es tu plantilla visual.")
        components.html(render_preview(selected_tool_id, raw_tool, answers), height=720, scrolling=True)

    st.markdown("### Resultado y siguiente paso")
    c1, c2 = st.columns(2)
    with c1:
        st.success(f"**Evidencia esperada:** {public.get('evidence') or public.get('output') or '—'}")
        st.caption(f"Criterio de calidad: {public.get('evidence_quality') or 'Revisar contra la metodología registrada.'}")
    with c2:
        nexts = next_checks_for_tool(selected_tool_id)
        if nexts:
            st.info("**Siguiente revisión posible:** " + "; ".join(x['tool_name'] for x in nexts[:2]))
        else:
            st.info("**Siguiente revisión:** reevaluar las brechas con la evidencia generada; no avanzar por una secuencia fija.")

    stage_num = _tool_stage_number(selected_tool_id)
    services = recommend_services(
        stage=stage_num,
        text=" ".join(str(v) for v in answers.values()),
        gap=(public.get('purpose') or ""),
        limit=3,
    )
    if services:
        st.markdown("### Servicios / mecanismos relacionados")
        scols = st.columns(len(services))
        for col, srv in zip(scols, services):
            with col:
                with st.container(border=True):
                    st.markdown(f"**{srv['name']}**")
                    st.write(srv['need'])
                    st.caption(srv['status'])

    export_md = f"# {public['name']}\n\n" + "\n\n".join(
        f"## {label}\n{answers.get(key) or 'Pendiente'}" for key,label in schema['fields']
    )
    d1, d2 = st.columns(2)
    with d1:
        st.download_button(
            "Descargar herramienta (.md)", export_md,
            file_name=f"{selected_tool_id}_{public['name'].replace(' ','_')}.md",
            mime="text/markdown", use_container_width=True
        )
    with d2:
        st.download_button(
            "Exportar datos (.json)",
            json.dumps({"tool_id":selected_tool_id,"tool":public['name'],"answers":answers}, ensure_ascii=False, indent=2),
            file_name=f"{selected_tool_id}_datos.json", mime="application/json", use_container_width=True
        )

elif page == "Ruta final":
    hero(
        "Ruta metodológica final",
        "Siete etapas para explicar el portafolio. No son una secuencia obligatoria: la IA y el motor activan la etapa pertinente según brecha, evidencia y objetivo.",
    )
    stage_tools = defaultdict(list)
    for tid in TOOLS:
        info = route_info_for_tool(tid)
        if info:
            stage_tools[int(info["stage"])].append(tid)
    for stage in ROUTE.get("route_defs", []):
        n = int(stage["orden"])
        st.markdown(f"### {n}. {stage['etapa']}")
        st.write(stage["pregunta"])
        c1, c2 = st.columns([2, 3])
        with c1:
            st.markdown(f"**Objetivo:** {stage['objetivo']}")
            st.markdown(f"**Evidencia/salida:** {stage['evidencia']}")
            st.caption(f"Alineación con mentoría: {stage['mentoria']} · {stage['rutas']}")
        with c2:
            names = [TOOLS[tid]["NOMBRE"] for tid in stage_tools.get(n, [])]
            st.write(" · ".join(names) if names else "Sin herramientas asignadas")
        st.divider()

elif page == "Diagnóstico con IA":
    hero(
        "No sé qué necesito",
        "Habla como hablarías normalmente. No tienes que conocer códigos, brechas ni nombres de herramientas.",
    )

    if "chat" not in st.session_state:
        st.session_state.chat = [
            {
                "role": "assistant",
                "content": (
                    "Cuéntame qué estás desarrollando y qué es lo que más te está frenando en este momento. "
                    "Puedes decirlo con tus propias palabras."
                ),
            }
        ]
    if "last_diagnosis" not in st.session_state:
        st.session_state.last_diagnosis = None
    if "last_recommendation" not in st.session_state:
        st.session_state.last_recommendation = None
    if "active_tool_id" not in st.session_state:
        st.session_state.active_tool_id = None

    for msg in st.session_state.chat:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    prompt = st.chat_input("Ej. Tengo una idea, pero una empresa me dijo que no sabe si va a funcionar...")
    if prompt:
        st.session_state.chat.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.write(prompt)

        last_reason = None
        if st.session_state.last_recommendation:
            last_reason = st.session_state.last_recommendation.get("reason")
        followup = tool_followup_answer(
            prompt,
            active_tool_id=st.session_state.active_tool_id,
            last_reason=last_reason,
        )

        if followup:
            answer = followup["answer"]
            st.session_state.active_tool_id = followup["tool_id"]
            st.session_state.chat.append({"role": "assistant", "content": answer})
            with st.chat_message("assistant"):
                st.markdown(answer)
        else:
            with st.spinner("Analizando tu proyecto con la IA local… La primera respuesta puede tardar un poco mientras el modelo se carga."):
                diagnosis = diagnose(prompt, st.session_state.chat, use_ai=use_ai)
            st.session_state.last_diagnosis = diagnosis

            if diagnosis.get("_local_ai_error"):
                st.warning(
                    "La IA local no respondió a tiempo o devolvió un formato inesperado. "
                    "Ruta CEDIA usó temporalmente el motor metodológico local para no perder tu diagnóstico."
                )
                with st.expander("Ver detalle técnico"):
                    st.code(diagnosis.get("_local_ai_error"))

            if diagnosis.get("requires_question"):
                questions = diagnosis.get("questions") or []
                summary = (diagnosis.get("summary") or "Todavía necesito un poco más de contexto.").strip()
                evidence = diagnosis.get("evidence_detected") or []

                parts = [summary]
                if evidence:
                    parts.append("**Evidencia que ya identifiqué:** " + "; ".join(evidence))
                if questions:
                    parts.append(
                        "**Para orientarte mejor, solo necesito saber:**\n\n"
                        + "\n".join(f"{i+1}. {q}" for i, q in enumerate(questions))
                    )
                answer = "\n\n".join(parts)

                st.session_state.chat.append({"role": "assistant", "content": answer})
                st.session_state.last_recommendation = None
                with st.chat_message("assistant"):
                    st.markdown(answer)
            else:
                rec = run_engine(diagnosis)
                st.session_state.last_recommendation = rec
                if rec.get("type") == "tool":
                    st.session_state.active_tool_id = rec.get("tool", {}).get("id")
                elif rec.get("type") == "action_service" and rec.get("support_tool"):
                    st.session_state.active_tool_id = rec["support_tool"].get("id")
                short = diagnosis.get("summary") or "Ya tengo suficiente contexto para proponer el siguiente paso."
                st.session_state.chat.append({"role": "assistant", "content": short})
                with st.chat_message("assistant"):
                    st.write(short)

    if st.session_state.last_diagnosis:
        d = st.session_state.last_diagnosis
        # Si la IA todavía está aclarando el caso, toda la respuesta se muestra
        # dentro de UNA sola burbuja conversacional. Evita duplicar la misma
        # información en un segundo bloque "Lo que entendimos".
        if not d.get("requires_question"):
            st.divider()
            st.markdown("### Resultado del diagnóstico")
            st.write(d.get("summary", "—"))
            if d.get("evidence_detected"):
                st.markdown("**Evidencia detectada:** " + "; ".join(d["evidence_detected"]))
            st.caption(f"Confianza de interpretación: {d.get('confidence','—')}")

    if st.session_state.last_recommendation:
        st.markdown("### Siguiente paso sugerido")
        show_recommendation(st.session_state.last_recommendation)
        rec = st.session_state.last_recommendation
        rec_tool = rec.get("tool") or rec.get("support_tool") or {}
        rec_tid = rec_tool.get("id")
        if rec_tid:
            st.button(
                "Desarrollar esta herramienta con IA",
                key="diag_open_builder",
                type="primary",
                on_click=open_tool_builder,
                args=(rec_tid,),
            )
            stage_num = _tool_stage_number(rec_tid)
            related_services = recommend_services(
                stage=stage_num,
                text=(d.get("summary","") if st.session_state.get("last_diagnosis") else ""),
                gap=rec.get("gap") or rec.get("title") or "",
                limit=3,
            )
            if related_services:
                st.markdown("#### Servicios / mecanismos que podrían apoyar")
                cols_srv = st.columns(len(related_services))
                for col, srv in zip(cols_srv, related_services):
                    with col:
                        with st.container(border=True):
                            st.markdown(f"**{srv['name']}**")
                            st.write(srv['need'])
                            st.caption(srv['status'])
        if rec.get("type") in ("tool", "action_service"):
            st.success("Ya puedes abrir **Pasaporte del proyecto** para ver el prediagnóstico consolidado.")

    c1, c2 = st.columns([1,4])
    with c1:
        if st.button("Reiniciar conversación"):
            st.session_state.chat = []
            st.session_state.last_diagnosis = None
            st.session_state.last_recommendation = None
            st.session_state.active_tool_id = None
            st.rerun()

elif page == "Pasaporte del proyecto":
    hero(
        "Pasaporte del proyecto",
        "Prediagnóstico consolidado para preparar una mentoría o el siguiente paso. No reemplaza revisión técnica, legal o institucional.",
    )
    d = st.session_state.get("last_diagnosis")
    rec = st.session_state.get("last_recommendation")
    if not d or not rec:
        st.info("Completa primero un diagnóstico para generar tu pasaporte. Abajo se muestra la estructura que tendrá.")
        fields = [
            ("Proyecto / resultado", "—"), ("Objetivo actual", "—"), ("TRL / CRL", "—"),
            ("Brecha prioritaria", "—"), ("Herramienta / acción", "—"), ("Evidencia esperada", "—"),
            ("Siguiente evaluación", "—"), ("Apoyo CEDIA sugerido", "—")
        ]
    else:
        tool = rec.get("tool") or rec.get("support_tool") or {}
        fields = [
            ("Proyecto / resultado", d.get("summary") or "—"),
            ("Objetivo actual", d.get("objective") or "—"),
            ("TRL / CRL", "No calculado en esta conversación"),
            ("Brecha prioritaria", rec.get("gap") or rec.get("title") or "—"),
            ("Herramienta / acción", rec.get("title") or "—"),
            ("Evidencia esperada", tool.get("evidence") or rec.get("criterion") or "—"),
            ("Siguiente evaluación", rec.get("next") or "Reevaluar brechas con la nueva evidencia."),
            ("Apoyo CEDIA sugerido", rec.get("service") or "Mentoría especializada si la brecha requiere acompañamiento humano."),
        ]
    for i in range(0, len(fields), 2):
        c1, c2 = st.columns(2)
        for col, item in zip((c1,c2), fields[i:i+2]):
            with col:
                st.markdown(f"**{item[0]}**")
                st.write(item[1])
    if d and rec:
        text = "# Pasaporte del proyecto\n\n" + "\n".join(f"**{k}:** {v}" for k,v in fields)
        st.download_button("Descargar pasaporte (.md)", text, file_name="pasaporte_ruta_cedia.md", mime="text/markdown")
    st.download_button(
        "Exportar respaldo completo del proyecto (.json)",
        json.dumps(_project_backup_payload(), ensure_ascii=False, indent=2),
        file_name="respaldo_ruta_cedia.json",
        mime="application/json",
    )

elif page == "TRL / CRL":
    hero(
        "TRL / CRL",
        "Evaluación orientativa construida con los criterios del Excel. La lógica institucional final de cálculo debe confirmarse con CEDIA antes de presentarla como resultado oficial.",
    )

    tab1, tab2 = st.tabs(["TRL orientativo", "CRL orientativo"])

    with tab1:
        project_type = st.selectbox(
            "Tipo de proyecto",
            ["Tecnología / Producto", "Software", "Farmacéutico"],
        )
        dimensions = [
            d for d in M["trl_dimensions"]
            if d.get("INSTRUMENTO") == "TRL" and d.get("TIPO_PROYECTO") == project_type
        ]
        selections = []
        for d in dimensions:
            did = d["ID_DIMENSION"]
            options = [
                c for c in M["trl_detail"]
                if c.get("TIPO_PROYECTO") == project_type and c.get("ID_DIMENSION") == did
            ]
            options = sorted(options, key=lambda x: float(x.get("PUNTAJE_REFERENCIA") or 0))
            labels = ["— Selecciona —"] + [
                f"{c.get('TRL_DESDE')}"
                + (f"–{c.get('TRL_HASTA')}" if c.get("TRL_HASTA") != c.get("TRL_DESDE") else "")
                + f" · {c.get('CRITERIO_RESPUESTA')}"
                for c in options
            ]
            choice = st.selectbox(d.get("DIMENSION"), labels, key=f"trl_{did}")
            if choice != labels[0]:
                idx = labels.index(choice) - 1
                c = options[idx]
                selections.append((float(d.get("PESO") or 0), float(c.get("PUNTAJE_REFERENCIA") or 0)))

        if st.button("Calcular estimación TRL"):
            if len(selections) != len(dimensions):
                st.warning("Completa todas las dimensiones para obtener la estimación.")
            else:
                total_weight = sum(w for w, _ in selections) or 1
                score = sum(w*s for w,s in selections) / total_weight
                st.metric("Indicador TRL orientativo", f"{score:.1f} / 9")
                st.caption(
                    "Este valor reproduce una media ponderada como prototipo. "
                    "Debe validarse contra la lógica exacta de la calculadora CEDIA antes de considerarlo oficial."
                )

    with tab2:
        dimensions = [d for d in M["trl_dimensions"] if d.get("INSTRUMENTO") == "CRL"]
        selections = []
        for d in dimensions:
            did = d["ID_DIMENSION"]
            options = [c for c in M["crl_detail"] if c.get("ID_DIMENSION") == did]
            options = sorted(options, key=lambda x: float(x.get("PUNTAJE_REFERENCIA") or 0))
            labels = ["— Selecciona —"] + [
                f"CRL {c.get('NIVEL_CRL')} · {c.get('CRITERIO_RESPUESTA')}" for c in options
            ]
            choice = st.selectbox(d.get("DIMENSION"), labels, key=f"crl_{did}")
            if choice != labels[0]:
                idx = labels.index(choice) - 1
                c = options[idx]
                selections.append((float(d.get("PESO") or 0), float(c.get("PUNTAJE_REFERENCIA") or 0)))

        if st.button("Calcular estimación CRL"):
            if len(selections) != len(dimensions):
                st.warning("Completa todas las dimensiones para obtener la estimación.")
            else:
                total_weight = sum(w for w, _ in selections) or 1
                score = sum(w*s for w,s in selections) / total_weight
                st.metric("Indicador CRL orientativo", f"{score:.1f} / 9")
                st.caption(
                    "La salida es orientativa para el MVP y debe contrastarse con la calculadora CEDIA vigente."
                )

elif page == "Servicios CEDIA":
    hero(
        "Servicios y mecanismos de innovación",
        "La app distingue herramientas de autogestión de acompañamiento, servicios especializados, intermediación y cofinanciamiento. Antes de publicar, CEDIA debe confirmar vigencia, nombres, condiciones y responsables.",
    )
    st.markdown("### Catálogo de conexión propuesto")
    categories = {}
    for srv in SERVICE_CATALOG:
        categories.setdefault(srv["type"], []).append(srv)
    for category, items in categories.items():
        st.markdown(f"#### {category}")
        cols = st.columns(3)
        for i, srv in enumerate(items):
            with cols[i % 3]:
                with st.container(border=True):
                    st.markdown(f"**{srv['name']}**")
                    st.write(srv['need'])
                    st.caption(srv['status'])

    st.markdown("### Servicio ya documentado en la base metodológica")
    real_services = [
        x for x in M.get("services", [])
        if str(x.get("TIPO_SERVICIO") or "").lower() not in ("herramienta", "herramienta propuesta")
    ]
    for srv in real_services:
        with st.expander(srv.get("NOMBRE_SERVICIO") or "Servicio"):
            st.write(srv.get("DESCRIPCION") or "")
            st.markdown(f"**Resultado:** {srv.get('RESULTADO_ESPERADO') or '—'}")
            st.markdown(f"**Modalidad:** {srv.get('MODALIDAD') or '—'}")
            st.caption(f"Estado: {srv.get('ESTADO_VALIDACION') or '—'}")

    st.warning("La conexión servicio-brecha es una capa de orientación. La publicación final requiere confirmar el portafolio institucional vigente de CEDIA.")

elif page == "Metodología":
    hero(
        "Cómo funciona por detrás",
        "El Excel no aparece frente al investigador: funciona como base metodológica del motor.",
    )

    st.markdown("### Flujo")
    st.code(
        "Lenguaje natural del investigador\n"
        "        ↓\n"
        "IA interpreta situación / objetivo / posibles brechas\n"
        "        ↓\n"
        "Motor consulta Excel → brechas + evidencias + prerrequisitos + reglas\n"
        "        ↓\n"
        "Recomendación de herramienta O acción/servicio\n"
        "        ↓\n"
        "IA explica el porqué en lenguaje simple",
        language=None,
    )

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Herramientas", len(M["tools"]))
    c2.metric("Brechas", len(M["gaps"]))
    c3.metric("Reglas", len(M["rules"]))
    c4.metric("Dependencias", len(M["dependencies"]))

    st.markdown("### Qué viene directamente del Excel")
    st.write(
        "`01_HERRAMIENTAS`, `02_BRECHAS`, `04_EVIDENCIAS`, `05_REGLAS_RUTA`, "
        "`07_DEPENDENCIAS`, `20_PRERREQUISITOS_EVIDENCIA`, además de las dimensiones y criterios TRL/CRL."
    )
    st.markdown("### Qué es propuesta del prototipo")
    st.write(
        "La conversación con IA, los bloqueos que no se resuelven con una plantilla "
        "(por ejemplo financiamiento o falta de prueba técnica) y las derivaciones a servicios "
        "están marcados como propuesta y requieren validación CEDIA."
    )


    st.divider()
    st.markdown("### Validación automática de consistencia")
    qa = methodology_qa()
    q1, q2, q3, q4 = st.columns(4)
    q1.metric("Herramientas cubiertas", f"{qa['tools_with_rule']}/{qa['tool_count']}")
    q2.metric("Brechas con regla", f"{qa['gaps_with_rule']}/{qa['gap_count']}")
    q3.metric("Prerrequisitos", f"{qa['tools_with_prereq']}/{qa['tool_count']}")
    q4.metric("Ciclos direccionales", qa["directional_cycles"])

    if qa["issues"]:
        st.warning("Hay inconsistencias estructurales que deben revisarse.")
        for issue in qa["issues"]:
            st.write("•", issue)
    else:
        st.success(
            "La red pasa los controles estructurales básicos: cada herramienta tiene regla, "
            "evidencia y prerrequisito; las referencias de dependencias son válidas y no se detectan ciclos "
            "en relaciones direccionales."
        )

    st.info(
        "Esto comprueba consistencia lógica, NO demuestra todavía que la metodología sea correcta en la práctica. "
        "Para eso debemos probar escenarios completos con investigadores y validar las reglas con CEDIA."
    )

    st.markdown("### Cómo se conecta un problema con el siguiente")
    st.write(
        "La ruta no debe ser una cadena fija. Al resolver una brecha, se registra la evidencia generada y se "
        "reevalúan las demás brechas. Solo mostramos un 'siguiente chequeo posible' cuando 07_DEPENDENCIAS "
        "contiene una relación explícita entre herramientas."
    )

    rows = []
    for tid, tool_data in TOOLS.items():
        current_gap = None
        for r in M["rules"]:
            if str(r.get("ID_REGLA","")).startswith("R-ACT-") and r.get("ID_HERRAMIENTA_RECOMENDADA") == tid:
                gid = r.get("ID_BRECHA")
                current_gap = GAPS.get(gid, {}).get("NOMBRE_BRECHA")
                break
        connected = next_checks_for_tool(tid)
        rows.append({
            "Herramienta": tool_data.get("NOMBRE"),
            "Brecha que aborda": current_gap or "—",
            "Siguiente revisión explícita": "; ".join(
                f"{x['tool_name']} ({x['relation']})" for x in connected[:3]
            ) or "Reevaluar brechas; sin relación direccional explícita"
        })
    st.dataframe(rows, use_container_width=True, hide_index=True)
